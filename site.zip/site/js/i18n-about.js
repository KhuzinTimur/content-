window.I18N_PAGE = {
  ru: {
    'page.about.eyebrow': 'О себе',
    'page.about.title': 'Из нефтегаза в UX/UI',
    'page.about.subtitle': 'Больше 11 лет я работал инженером-технологом в нефтегазовой отрасли, а сейчас проектирую цифровые интерфейсы. Ниже — как прошёл этот путь и что взял с собой.',

    'about.story.title': 'Почему я перешёл в дизайн',
    'about.story.p1': 'В нефтянке я прошёл путь от оператора по добыче до главного специалиста: анализировал производственные данные, искал причины отклонений в работе оборудования, принимал решения в условиях жёстких ограничений. Работа была интересной, но со временем я понял, что хочу создавать продукты, которые видят и используют люди — а не только оптимизировать процессы.',
    'about.story.p2': 'Я начал изучать UX/UI, прошёл переподготовку, сделал несколько учебных и командных проектов, стажировался в Ozon. Сейчас совмещаю инженерную работу с дизайном и ищу возможность перейти в продуктовую команду на постоянной основе.',

    'about.transfer.title': 'Что переносится из инженерии в дизайн',
    'about.transfer.systemic.title': 'Системное мышление',
    'about.transfer.systemic.desc': 'Привык видеть картину целиком: как один элемент влияет на другой, как решение в одном месте меняет весь сценарий.',
    'about.transfer.analytical.title': 'Аналитический подход',
    'about.transfer.analytical.desc': 'Анализировал тысячи производственных показателей, искал причины сбоев — тот же подход применяю к пользовательским данным и гипотезам.',
    'about.transfer.constraints.title': 'Работа с ограничениями',
    'about.transfer.constraints.desc': 'Технические, ресурсные, временные — умею находить рабочее решение даже без идеальных условий.',
    'about.transfer.teams.title': 'Взаимодействие с командами',
    'about.transfer.teams.desc': 'Координировал инженеров и подрядчиков, работал с руководством — понимаю, как выстраивать коммуникацию в команде.',

    'about.experience.title': 'Опыт',

    'exp.gitverse.period': '2025 · Командный проект',
    'exp.gitverse.role': 'UX/UI Designer — GitVerse (SberTech)',
    'exp.gitverse.desc': 'В составе продуктовой команды участвовал в редизайне IT-блога и перезапуске AI-ассистента. Формулировал JTBD для разных сегментов пользователей, проектировал информационную архитектуру, участвовал в разработке дизайн-системы.',
    'exp.gitverse.result': 'Сократил время поиска информации на 30% за счёт упрощённой навигации. AI-ассистент стал ключевой фичей продукта.',

    'exp.ozon.period': '2025 · Стажировка',
    'exp.ozon.role': 'UX/UI Designer Intern — Ozon',
    'exp.ozon.desc': 'Стажировка в мобильной команде под руководством арт-директора. Спроектировал новый функциональный блок приложения — от исследования аудитории до прототипа, провёл UX-тест с международной аудиторией.',
    'exp.ozon.result': 'Usability Score прототипа вырос с 3,5 до 4,7 из 5 за счёт итеративных улучшений. Подготовил 20+ экранов к передаче в разработку.',

    'exp.okkta.period': '2024 · Хакатон',
    'exp.okkta.role': 'UX/UI Designer — OKKTA MegaHackathon',
    'exp.okkta.desc': 'Хакатон от заказчика Oneum — сервиса чат-ботов на базе ChatGPT. Координировал UX/UI-направление команды из 6 дизайнеров, разработал экраны «Профиль» и «Тарифы», создал библиотеку компонентов.',
    'exp.okkta.result': 'Команда заняла 2-е место. Прототип стал основой для дальнейшей разработки.',

    'exp.prokennex.period': '2024 · Соло-проект',
    'exp.prokennex.role': 'UX/UI Designer — Prokennex',
    'exp.prokennex.desc': 'Учебный проект по редизайну сайта производителя теннисных ракеток. Проработал пользовательские сценарии для пяти сегментов аудитории, переработал информационную архитектуру, сделал адаптив под 4 разрешения.',
    'exp.prokennex.result': 'Создал анимацию главной страницы в After Effects. Разработал современный интерфейс с чёткой визуальной иерархией.',

    'exp.elevateu.period': '2024 · Соло-проект',
    'exp.elevateu.role': 'UX/UI Designer — ElevateU',
    'exp.elevateu.desc': 'Учебный проект по созданию мобильного образовательного приложения. Провёл исследование аудитории, разработал портреты пользователей и JTBD, создал 24 wireframes и дизайн-систему.',
    'exp.elevateu.result': 'Провёл юзабилити-тестирование с 5 респондентами и внёс улучшения по результатам.',

    'exp.engineering.period': '2014–2026 · 11+ лет',
    'exp.engineering.role': 'Инженер-технолог → Главный специалист — Роснефть, ННК',
    'exp.engineering.desc': 'Прошёл путь от оператора по добыче до ведущего инженера-технолога в «Роснефти» (РН-Ванкор, Удмуртнефть, Белкамнефть) и «ННК — Самаранефтегаз». Анализировал производственные данные, разрабатывал технические мероприятия, координировал инженерные команды.',
    'exp.engineering.result': 'Снизил простои оборудования на 15%, энергопотребление — на 7% ежегодно. Увеличил межремонтный период оборудования с 320 до 510 суток.',

  },
  en: {
    'page.about.eyebrow': 'About',
    'page.about.title': 'From oil & gas to UX/UI',
    'page.about.subtitle': 'For more than 11 years I worked as a process engineer in oil & gas, and now I design digital interfaces. Here\u2019s how that path went and what I brought with me.',

    'about.story.title': 'Why I moved into design',
    'about.story.p1': 'In oil & gas I went from field operator to chief specialist: analyzing production data, investigating equipment deviations, making decisions under tight constraints. The work was interesting, but over time I realized I wanted to build products that people actually see and use — not just optimize processes.',
    'about.story.p2': 'I started learning UX/UI, completed a retraining program, built several academic and team projects, and interned at Ozon. Right now I balance engineering work with design and I\u2019m looking for a chance to move into a product team full-time.',

    'about.transfer.title': 'What carries over from engineering',
    'about.transfer.systemic.title': 'Systems thinking',
    'about.transfer.systemic.desc': 'Used to seeing the whole picture: how one element affects another, how a decision in one place changes the whole flow.',
    'about.transfer.analytical.title': 'Analytical approach',
    'about.transfer.analytical.desc': 'Analyzed thousands of production metrics, investigated failures — I apply the same approach to user data and hypotheses.',
    'about.transfer.constraints.title': 'Working within constraints',
    'about.transfer.constraints.desc': 'Technical, resource, time — I can find a workable solution even without ideal conditions.',
    'about.transfer.teams.title': 'Working across teams',
    'about.transfer.teams.desc': 'Coordinated engineers and contractors, worked with management — I know how to build communication within a team.',

    'about.experience.title': 'Experience',

    'exp.gitverse.period': '2025 · Team project',
    'exp.gitverse.role': 'UX/UI Designer — GitVerse (SberTech)',
    'exp.gitverse.desc': 'Part of a product team redesigning a developer blog and relaunching an AI assistant. Defined JTBD for different user segments, designed the information architecture, contributed to the design system.',
    'exp.gitverse.result': 'Cut time-to-find-information by 30% through simplified navigation. The AI assistant became a key product feature.',

    'exp.ozon.period': '2025 · Internship',
    'exp.ozon.role': 'UX/UI Designer Intern — Ozon',
    'exp.ozon.desc': 'Internship on the mobile team under an art director. Designed a new functional block for the app — from audience research to prototype — and ran a UX test with an international audience.',
    'exp.ozon.result': 'Prototype Usability Score rose from 3.5 to 4.7 out of 5 through iterative improvements. Prepared 20+ screens for handoff to development.',

    'exp.okkta.period': '2024 · Hackathon',
    'exp.okkta.role': 'UX/UI Designer — OKKTA MegaHackathon',
    'exp.okkta.desc': 'A hackathon for client Oneum, a ChatGPT-based chatbot service. Coordinated the UX/UI track for a team of 6 designers, designed the Profile and Pricing screens, built a component library.',
    'exp.okkta.result': 'The team placed 2nd. The prototype became the basis for further development.',

    'exp.prokennex.period': '2024 · Solo project',
    'exp.prokennex.role': 'UX/UI Designer — Prokennex',
    'exp.prokennex.desc': 'An academic redesign project for a tennis racket manufacturer\u2019s website. Mapped user scenarios for five audience segments, reworked the information architecture, built responsive layouts across 4 breakpoints.',
    'exp.prokennex.result': 'Created a homepage animation in After Effects. Delivered a modern interface with a clear visual hierarchy.',

    'exp.elevateu.period': '2024 · Solo project',
    'exp.elevateu.role': 'UX/UI Designer — ElevateU',
    'exp.elevateu.desc': 'An academic project designing a mobile education app. Ran audience research, built user personas and JTBD, created 24 wireframes and a design system.',
    'exp.elevateu.result': 'Ran a usability test with 5 respondents and shipped improvements based on the findings.',

    'exp.engineering.period': '2014–2026 · 11+ years',
    'exp.engineering.role': 'Process Engineer → Chief Specialist — Rosneft, NNK',
    'exp.engineering.desc': 'Went from field operator to lead process engineer at Rosneft (RN-Vankor, Udmurtneft, Belkamneft) and NNK — Samaraneftegaz. Analyzed production data, developed technical improvements, coordinated engineering teams.',
    'exp.engineering.result': 'Cut equipment downtime by 15%, energy use by 7% annually. Extended equipment service intervals from 320 to 510 days.',

  },
};
